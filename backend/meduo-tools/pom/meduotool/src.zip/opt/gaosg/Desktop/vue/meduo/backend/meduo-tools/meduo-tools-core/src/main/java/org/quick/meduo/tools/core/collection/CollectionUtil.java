package org.quick.meduo.tools.core.collection;

/**
 * 集合相关工具类，包括数组，是{@link CollUtil} 的别名工具类类
 * 
 * @author xiaoleilu
 * @see CollUtil
 */
public class CollectionUtil extends CollUtil{
}
