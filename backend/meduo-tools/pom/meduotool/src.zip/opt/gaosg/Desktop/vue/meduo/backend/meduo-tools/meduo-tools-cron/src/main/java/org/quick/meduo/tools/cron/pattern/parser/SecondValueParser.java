package org.quick.meduo.tools.cron.pattern.parser;

/**
 * 秒值处理
 * @author Looly
 *
 */
public class SecondValueParser extends MinuteValueParser{
}
