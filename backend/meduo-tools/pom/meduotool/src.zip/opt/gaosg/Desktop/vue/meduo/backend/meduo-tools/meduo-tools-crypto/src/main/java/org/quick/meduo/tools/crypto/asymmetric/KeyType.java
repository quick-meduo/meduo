package org.quick.meduo.tools.crypto.asymmetric;

/**
 * 密钥类型
 * 
 * @author Looly
 *
 */
public enum KeyType {
	PrivateKey, PublicKey
}